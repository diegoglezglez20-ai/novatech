import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowRight, Sparkles, Globe, ShoppingBag, Search, Bot, Wrench, Share2, Palette,
  Check, Star, Phone, Mail, MapPin, Instagram, Linkedin, Facebook, Menu, X,
  Zap, Shield, Rocket, Heart, ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NovaTech Solutions — Webs e IA para pequeñas empresas" },
      { name: "description", content: "Agencia de desarrollo web y automatización con IA. Diseñamos webs, tiendas online y soluciones inteligentes para pymes y autónomos." },
    ],
  }),
  component: Index,
});

const services = [
  { icon: Globe, title: "Diseño Web Profesional", desc: "Webs corporativas modernas, rápidas y optimizadas para convertir visitas en clientes." },
  { icon: ShoppingBag, title: "Tiendas Online", desc: "E-commerce a medida con pasarelas de pago, gestión de stock y experiencia de compra fluida." },
  { icon: Search, title: "Posicionamiento SEO", desc: "Aparece en lo más alto de Google con estrategias SEO técnicas y de contenido." },
  { icon: Bot, title: "Automatización con IA", desc: "Chatbots y asistentes inteligentes que atienden a tus clientes 24/7." },
  { icon: Wrench, title: "Mantenimiento Web", desc: "Tu web siempre actualizada, segura y funcionando al 100%." },
  { icon: Share2, title: "Gestión de Redes Sociales", desc: "Estrategia, contenido y comunidad para hacer crecer tu marca online." },
  { icon: Palette, title: "Identidad Corporativa", desc: "Logos, branding y diseño visual que conectan con tu público." },
];

const projects = [
  { title: "Restaurante La Brasa", tag: "Web + Reservas", color: "from-blue-500 to-cyan-400" },
  { title: "Clínica Dental Sonrisa", tag: "Web + Chatbot IA", color: "from-indigo-500 to-blue-400" },
  { title: "Boutique Marina", tag: "Tienda Online", color: "from-sky-500 to-blue-600" },
  { title: "Gestoría Álvarez", tag: "Web Corporativa + SEO", color: "from-blue-600 to-indigo-500" },
  { title: "Gimnasio Pulse", tag: "App + Automatización", color: "from-cyan-500 to-blue-500" },
  { title: "Floristería Pétalo", tag: "E-commerce + Branding", color: "from-blue-400 to-sky-300" },
];

const testimonials = [
  { name: "Carlos Martín", role: "Dueño · Restaurante La Brasa", text: "NovaTech rediseñó nuestra web y montó un sistema de reservas. Las reservas online han subido un 60% en 3 meses." },
  { name: "Lucía Hernández", role: "Directora · Clínica Sonrisa", text: "El chatbot con IA atiende a nuestros pacientes a cualquier hora. Hemos reducido llamadas y mejorado la experiencia." },
  { name: "David Torres", role: "Fundador · Boutique Marina", text: "Profesionales, rápidos y muy atentos. Nuestra tienda online vende ya el doble que el año pasado." },
  { name: "Ana Ruiz", role: "Socia · Gestoría Álvarez", text: "El posicionamiento SEO ha sido espectacular. Ahora aparecemos los primeros en Google en nuestra zona." },
];

const faqs = [
  { q: "¿Cuánto tarda en estar lista mi web?", a: "Una web profesional estándar se entrega entre 2 y 4 semanas. Proyectos más complejos (tiendas online, integraciones) pueden requerir entre 4 y 8 semanas." },
  { q: "¿Trabajáis con pequeños negocios y autónomos?", a: "Sí. Nuestro foco son autónomos, pymes, restaurantes, clínicas y comercios locales. Adaptamos cada proyecto al tamaño y presupuesto del cliente." },
  { q: "¿Qué incluye la automatización con IA?", a: "Diseñamos chatbots y asistentes virtuales que responden consultas frecuentes, gestionan reservas, captan leads y se integran con WhatsApp, web y redes sociales." },
  { q: "¿Ofrecéis mantenimiento después del lanzamiento?", a: "Sí, contamos con planes de mantenimiento mensual que incluyen actualizaciones, copias de seguridad, soporte y mejoras continuas." },
  { q: "¿Cuánto cuesta una web?", a: "Cada proyecto es único. Tras una llamada gratuita te enviamos un presupuesto personalizado, transparente y sin sorpresas." },
];

const values = [
  { icon: Rocket, label: "Innovación" },
  { icon: Shield, label: "Transparencia" },
  { icon: Zap, label: "Rapidez" },
  { icon: Sparkles, label: "Calidad" },
  { icon: Heart, label: "Atención personalizada" },
];

function Index() {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("¡Mensaje enviado! Te contactaremos en menos de 24h.");
    (e.target as HTMLFormElement).reset();
  };

  const navLinks = [
    { href: "#inicio", label: "Inicio" },
    { href: "#nosotros", label: "Nosotros" },
    { href: "#servicios", label: "Servicios" },
    { href: "#proyectos", label: "Proyectos" },
    { href: "#opiniones", label: "Opiniones" },
    { href: "#faq", label: "FAQ" },
    { href: "#contacto", label: "Contacto" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* NAV */}
      <header className="sticky top-0 z-50 backdrop-blur-lg bg-background/80 border-b border-border/60">
        <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
          <a href="#inicio" className="flex items-center gap-2 font-display font-bold text-lg">
            <span className="inline-grid place-items-center w-8 h-8 rounded-lg gradient-brand text-white">
              <Sparkles className="w-4 h-4" />
            </span>
            <span>NovaTech<span className="text-sky">.</span></span>
          </a>
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="text-muted-foreground hover:text-primary transition-colors">{l.label}</a>
            ))}
          </nav>
          <a href="#contacto" className="hidden lg:inline-flex">
            <Button className="rounded-full gradient-brand text-white hover:opacity-90">
              Solicita presupuesto <ArrowRight className="w-4 h-4" />
            </Button>
          </a>
          <button className="lg:hidden p-2" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menú">
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-border bg-background">
            <div className="px-6 py-4 flex flex-col gap-3">
              {navLinks.map((l) => (
                <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="py-2 text-sm font-medium text-muted-foreground hover:text-primary">{l.label}</a>
              ))}
              <a href="#contacto" onClick={() => setMenuOpen(false)}>
                <Button className="w-full rounded-full gradient-brand text-white">Solicita presupuesto</Button>
              </a>
            </div>
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="inicio" className="relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 -z-10">
          <div className="absolute top-20 -left-32 w-[28rem] h-[28rem] rounded-full bg-sky/20 blur-3xl animate-blob" />
          <div className="absolute top-40 right-0 w-[32rem] h-[32rem] rounded-full bg-primary/15 blur-3xl animate-blob" style={{ animationDelay: "4s" }} />
        </div>
        <div className="mx-auto max-w-7xl px-6 pt-20 pb-28 lg:pt-32 lg:pb-40 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-xs font-medium text-primary mb-8 animate-float-in">
            <Sparkles className="w-3.5 h-3.5" /> Webs e IA para pequeñas empresas
          </div>
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-extrabold tracking-tight leading-[1.05] animate-float-in" style={{ animationDelay: "0.1s" }}>
            Impulsamos tu negocio<br />
            <span className="text-gradient-brand">hacia el futuro.</span>
          </h1>
          <p className="mt-8 max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground animate-float-in" style={{ animationDelay: "0.2s" }}>
            Diseñamos webs profesionales, tiendas online y automatizaciones con inteligencia artificial para autónomos, pymes y comercios que quieren crecer.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4 animate-float-in" style={{ animationDelay: "0.3s" }}>
            <a href="#contacto">
              <Button size="lg" className="rounded-full gradient-brand text-white hover:opacity-90 px-8 h-12 glow-brand">
                Solicita presupuesto <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
            <a href="#servicios">
              <Button size="lg" variant="outline" className="rounded-full px-8 h-12 border-border">
                Ver servicios
              </Button>
            </a>
          </div>
          <div className="mt-16 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-sm text-muted-foreground animate-float-in" style={{ animationDelay: "0.4s" }}>
            {values.map((v) => (
              <div key={v.label} className="flex items-center gap-2">
                <v.icon className="w-4 h-4 text-sky" /> {v.label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NOSOTROS */}
      <section id="nosotros" className="py-24 bg-secondary/50">
        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-sky">Sobre nosotros</span>
            <h2 className="mt-4 text-4xl md:text-5xl font-bold leading-tight">Una agencia tecnológica al servicio de los pequeños negocios.</h2>
            <p className="mt-6 text-lg text-muted-foreground">
              NovaTech Solutions nació en 2023 de la mano de un equipo de desarrolladores y diseñadores con una misión clara: <strong className="text-foreground">ayudar a pequeños negocios a digitalizarse</strong> con soluciones modernas, rápidas y asequibles.
            </p>
            <p className="mt-4 text-lg text-muted-foreground">
              Combinamos diseño, código e inteligencia artificial para entregar webs que no solo se ven bien, sino que <strong className="text-foreground">venden, automatizan y escalan</strong>.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-6">
              {[
                { n: "+80", l: "Proyectos entregados" },
                { n: "98%", l: "Clientes satisfechos" },
                { n: "24/7", l: "Soporte y monitoreo" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="text-3xl md:text-4xl font-bold text-gradient-brand">{s.n}</div>
                  <div className="text-sm text-muted-foreground mt-1">{s.l}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-3xl gradient-brand glow-brand p-1">
              <div className="w-full h-full rounded-[22px] bg-background grid place-items-center p-10">
                <div className="grid grid-cols-2 gap-4 w-full">
                  {values.map((v, i) => (
                    <div key={v.label} className="rounded-2xl border border-border p-6 bg-secondary/40 hover:bg-secondary transition-colors" style={{ transform: i % 2 ? "translateY(20px)" : "" }}>
                      <v.icon className="w-6 h-6 text-sky mb-3" />
                      <div className="font-semibold text-sm">{v.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICIOS */}
      <section id="servicios" className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-widest text-sky">Servicios</span>
            <h2 className="mt-4 text-4xl md:text-5xl font-bold">Todo lo que tu negocio necesita para crecer online.</h2>
            <p className="mt-4 text-lg text-muted-foreground">Diseño, desarrollo, marketing e inteligencia artificial bajo un mismo equipo.</p>
          </div>
          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <div key={s.title} className="group relative rounded-2xl border border-border p-8 bg-card hover:border-sky/60 hover:-translate-y-1 transition-all duration-300">
                <div className="w-12 h-12 rounded-xl gradient-brand text-white grid place-items-center mb-5 group-hover:scale-110 transition-transform">
                  <s.icon className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROYECTOS */}
      <section id="proyectos" className="py-24 bg-secondary/50">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-wrap items-end justify-between gap-6 mb-14">
            <div className="max-w-2xl">
              <span className="text-xs font-semibold uppercase tracking-widest text-sky">Proyectos</span>
              <h2 className="mt-4 text-4xl md:text-5xl font-bold">Casos reales, resultados reales.</h2>
            </div>
            <p className="text-muted-foreground max-w-md">Una selección de los proyectos que hemos lanzado junto a nuestros clientes.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((p) => (
              <article key={p.title} className="group relative overflow-hidden rounded-2xl border border-border bg-card hover:-translate-y-1 transition-all duration-300">
                <div className={`aspect-[4/3] bg-gradient-to-br ${p.color} relative overflow-hidden`}>
                  <div className="absolute inset-0 opacity-30 [background-image:radial-gradient(circle_at_20%_20%,white_0%,transparent_40%),radial-gradient(circle_at_80%_80%,white_0%,transparent_40%)]" />
                  <div className="absolute bottom-4 left-4 text-white/90 text-xs font-medium px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm border border-white/20">{p.tag}</div>
                </div>
                <div className="p-6 flex items-center justify-between">
                  <h3 className="font-semibold">{p.title}</h3>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-sky group-hover:translate-x-1 transition-all" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* OPINIONES */}
      <section id="opiniones" className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-semibold uppercase tracking-widest text-sky">Opiniones</span>
            <h2 className="mt-4 text-4xl md:text-5xl font-bold">Lo que dicen nuestros clientes.</h2>
          </div>
          <div className="mt-14 grid md:grid-cols-2 gap-6">
            {testimonials.map((t) => (
              <div key={t.name} className="rounded-2xl border border-border bg-card p-8 hover:border-sky/60 transition-colors">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-sky text-sky" />
                  ))}
                </div>
                <p className="text-lg leading-relaxed">"{t.text}"</p>
                <div className="mt-6 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full gradient-brand text-white grid place-items-center font-bold text-sm">
                    {t.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-24 bg-secondary/50">
        <div className="mx-auto max-w-3xl px-6">
          <div className="text-center mb-14">
            <span className="text-xs font-semibold uppercase tracking-widest text-sky">FAQ</span>
            <h2 className="mt-4 text-4xl md:text-5xl font-bold">Preguntas frecuentes.</h2>
          </div>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`} className="rounded-2xl border border-border bg-card px-6 data-[state=open]:border-sky/60">
                <AccordionTrigger className="text-left font-semibold hover:no-underline py-5">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CONTACTO */}
      <section id="contacto" className="py-24">
        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-12">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-sky">Contacto</span>
            <h2 className="mt-4 text-4xl md:text-5xl font-bold leading-tight">¿Listo para impulsar tu negocio?</h2>
            <p className="mt-4 text-lg text-muted-foreground">Cuéntanos tu proyecto y te enviamos un presupuesto personalizado en menos de 24 horas.</p>
            <div className="mt-10 space-y-5">
              <a href="tel:+34912345678" className="flex items-center gap-4 group">
                <div className="w-11 h-11 rounded-xl bg-secondary grid place-items-center text-primary group-hover:gradient-brand group-hover:text-white transition-all">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Teléfono</div>
                  <div className="font-semibold">+34 912 345 678</div>
                </div>
              </a>
              <a href="mailto:contacto@novatechsolutions.es" className="flex items-center gap-4 group">
                <div className="w-11 h-11 rounded-xl bg-secondary grid place-items-center text-primary group-hover:gradient-brand group-hover:text-white transition-all">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Email</div>
                  <div className="font-semibold">contacto@novatechsolutions.es</div>
                </div>
              </a>
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-xl bg-secondary grid place-items-center text-primary">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Oficina</div>
                  <div className="font-semibold">Calle Innovación 15, Madrid</div>
                </div>
              </div>
            </div>
            <div className="mt-10 flex items-center gap-3">
              <a href="#" aria-label="Instagram" className="w-10 h-10 rounded-full border border-border grid place-items-center hover:gradient-brand hover:text-white hover:border-transparent transition-all"><Instagram className="w-4 h-4" /></a>
              <a href="#" aria-label="LinkedIn" className="w-10 h-10 rounded-full border border-border grid place-items-center hover:gradient-brand hover:text-white hover:border-transparent transition-all"><Linkedin className="w-4 h-4" /></a>
              <a href="#" aria-label="Facebook" className="w-10 h-10 rounded-full border border-border grid place-items-center hover:gradient-brand hover:text-white hover:border-transparent transition-all"><Facebook className="w-4 h-4" /></a>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="rounded-3xl border border-border bg-card p-8 md:p-10 space-y-5 glow-brand">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Nombre</label>
                <Input required maxLength={100} placeholder="Tu nombre" className="rounded-xl h-11" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Teléfono</label>
                <Input maxLength={20} placeholder="600 000 000" className="rounded-xl h-11" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Email</label>
              <Input type="email" required maxLength={255} placeholder="tu@email.com" className="rounded-xl h-11" />
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">Cuéntanos tu proyecto</label>
              <Textarea required maxLength={1000} rows={5} placeholder="¿Qué necesitas? Web, tienda online, chatbot..." className="rounded-xl resize-none" />
            </div>
            <Button type="submit" size="lg" className="w-full rounded-full gradient-brand text-white hover:opacity-90 h-12">
              Enviar mensaje <ArrowRight className="w-4 h-4" />
            </Button>
            <p className="text-xs text-muted-foreground text-center flex items-center justify-center gap-1.5">
              <Check className="w-3 h-3 text-sky" /> Respondemos en menos de 24 horas.
            </p>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border py-12">
        <div className="mx-auto max-w-7xl px-6 flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-2 font-display font-bold">
            <span className="inline-grid place-items-center w-7 h-7 rounded-md gradient-brand text-white">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            NovaTech Solutions
          </div>
          <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} NovaTech Solutions. Todos los derechos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
